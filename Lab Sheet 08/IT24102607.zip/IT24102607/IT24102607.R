setwd("C:\\Users\\DELL\\OneDrive\\Desktop\\IT24102607")

data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
weights <- data$Weight

#1
pop_mean <- mean(weights)
pop_sd   <- sd(weights)

cat("Q1: Population Mean =", pop_mean, "\n")
cat("Q1: Population Std. Deviation =", pop_sd, "\n\n")

#2
set.seed(123)  
sample_means <- c()
sample_sds   <- c()

for (i in 1:25) {
  sample_data <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i]   <- sd(sample_data)
  cat("Sample", i, ": Mean =", sample_means[i],
      ", SD =", sample_sds[i], "\n")
}

#3
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means   <- sd(sample_means)

cat("\nQ3: Mean of 25 Sample Means =", mean_of_sample_means, "\n")
cat("Q3: SD of 25 Sample Means =", sd_of_sample_means, "\n")

cat("\nRelationship:\n")
cat("- Mean of sample means ≈ Population mean\n")
cat("- SD of sample means < Population SD\n")

