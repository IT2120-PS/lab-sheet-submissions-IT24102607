setwd("C:\\Users\\DELL\\OneDrive\\Desktop\\IT24102607")


# 1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, check.names = FALSE)

names(Delivery_Times)[names(Delivery_Times) == "Delivery_Time_(minutes)"] <- "DeliveryTime"

# 2
breaks <- seq(20, 70, length.out = 10)

hist(Delivery_Times$DeliveryTime,
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times (right-open)",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")

# 4
h <- hist(Delivery_Times$DeliveryTime, breaks = breaks, right = FALSE, plot = FALSE)
cum <- c(0, cumsum(h$counts))
plot(breaks, cum, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")

