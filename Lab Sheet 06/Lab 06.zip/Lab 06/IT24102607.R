setwd("C:\\Users\\ASUS\\Desktop\\PS\\7. week seven\\IT24102607")

#Question 01
# (i)
#Binomial Distribution

#n = 50, p = 0.85,X= number of students who passed the test out of 50
# (ii) = P(x>=47)
pbinom(46,50,0.85,lower.tail=FALSE)

#Question 02
# (i)
# x = number of calls received in an hour

# (ii)
#Poisson Distribution

# (iii)
#lambda = 12
#P(x=15)
dpois(15,12)

